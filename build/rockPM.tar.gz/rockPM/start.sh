#!/usr/bin/env bash
mkdir logs > /dev/null 2>&1
cp nohup.out ./logs/nohup.$(date '+%Y%m%d%H%M%S').out > /dev/null 2>&1
nohup java -Xmx512m -jar ./rockPM-web-1.0.0.jar > /dev/null 2>&1
sleep 1
tail -100 nohup.out
echo "rockPM web launching..."
echo "See the nohup.out."

