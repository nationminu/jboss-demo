rm -f *.rockPM
